import express from "express";
import dotenv from "dotenv";
import path from "node:path";
import { fileURLToPath } from "node:url";

dotenv.config();

const app = express();
const port = process.env.PORT || 3000;
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "..", "public")));

const defaultModel = process.env.OPENAI_MODEL || "gpt-5.6-luna";

function cleanText(value, max = 4000) {
  return String(value ?? "").slice(0, max);
}

app.post("/api/chat", async (req, res) => {
  try {
    if (!process.env.OPENAI_API_KEY) {
      return res.status(500).json({ error: "Server AI key is not configured." });
    }

    const character = req.body.character || {};
    const messages = Array.isArray(req.body.messages) ? req.body.messages.slice(-20) : [];
    const memory = Array.isArray(req.body.memory) ? req.body.memory.slice(-20) : [];

    const characterPrompt = `
You are an AI character inside Mouth Mover.

Character name: ${cleanText(character.name, 100)}
Description: ${cleanText(character.description, 1200)}
Personality: ${cleanText(character.personality, 1600)}
Style: ${cleanText(character.style, 600)}

Stay consistent with this fictional character. Never claim to be a real person.
Keep responses appropriate for a general-audience teen-friendly app. Do not produce sexual content involving minors or assist with dangerous, illegal, or self-harm activities.
If the user asks for something unsafe, briefly refuse and redirect to a safe alternative.
`;

    const memoryText = memory.length
      ? "\nRelevant memory notes:\n- " + memory.map(cleanText).join("\n- ")
      : "";

    const input = [
      { role: "system", content: characterPrompt + memoryText },
      ...messages.map(m => ({
        role: m.role === "assistant" ? "assistant" : "user",
        content: cleanText(m.content)
      }))
    ];

    const response = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`
      },
      body: JSON.stringify({
        model: defaultModel,
        input,
        max_output_tokens: 500
      })
    });

    const data = await response.json();

    if (!response.ok) {
      console.error(data);
      return res.status(response.status).json({
        error: data?.error?.message || "AI request failed."
      });
    }

    return res.json({ text: data.output_text || "I couldn't think of a response." });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Something went wrong while contacting the AI." });
  }
});

app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "..", "public", "index.html"));
});

app.listen(port, () => {
  console.log(`Mouth Mover running at http://localhost:${port}`);
});
