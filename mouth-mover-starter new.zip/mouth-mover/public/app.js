const seedCharacters = [
 {id:"zayne",name:"Zayne",description:"A mysterious strategist who always seems one step ahead.",personality:"Calm, clever, observant, dry sense of humor.",style:"Short, confident replies with occasional teasing.",category:"Mystery",emoji:"🖤"},
 {id:"luna",name:"Luna",description:"An energetic dreamer who loves impossible ideas.",personality:"Cheerful, curious, imaginative and supportive.",style:"Expressive and upbeat.",category:"Fantasy",emoji:"🌙"},
 {id:"kai",name:"Kai",description:"A quiet inventor who would rather build than brag.",personality:"Reserved, thoughtful, loyal and analytical.",style:"Concise and thoughtful.",category:"Sci-Fi",emoji:"⚙️"},
 {id:"elara",name:"Elara",description:"A mysterious traveler with a talent for strange stories.",personality:"Confident, playful, secretive and kind.",style:"Dramatic but friendly.",category:"Adventure",emoji:"✨"},
 {id:"calix",name:"Calix",description:"Your competitive classmate who secretly wants to help.",personality:"Competitive, witty, protective and honest.",style:"Casual banter.",category:"School",emoji:"📚"},
 {id:"seraphina",name:"Seraphina",description:"A cosmic storyteller who collects questions about the universe.",personality:"Wise, curious, gentle and enthusiastic.",style:"Poetic but easy to understand.",category:"Fantasy",emoji:"🌌"}
];

let characters = JSON.parse(localStorage.getItem("mm_characters") || "null") || seedCharacters;
let favorites = JSON.parse(localStorage.getItem("mm_favorites") || "[]");
let histories = JSON.parse(localStorage.getItem("mm_histories") || "{}");
let memory = JSON.parse(localStorage.getItem("mm_memory") || "{}");
let current = null;
let activeCategory = "All";

const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];

function save(){
 localStorage.setItem("mm_characters",JSON.stringify(characters));
 localStorage.setItem("mm_favorites",JSON.stringify(favorites));
 localStorage.setItem("mm_histories",JSON.stringify(histories));
 localStorage.setItem("mm_memory",JSON.stringify(memory));
}

function showView(name){
 $$(".view").forEach(v=>v.classList.remove("active-view"));
 $(`#${name}View`).classList.add("active-view");
 $$(".nav").forEach(n=>n.classList.toggle("active",n.dataset.view===name));
}

function card(c){
 const fav=favorites.includes(c.id)?"♥":"♡";
 return `<article class="card" data-id="${c.id}">
  <div class="card-art">${c.emoji||"✦"}</div>
  <div class="card-body">
   <div class="card-title">${escapeHtml(c.name)}</div>
   <div class="muted">${escapeHtml(c.description)}</div>
   <div class="card-footer"><span>${fav} Favorite</span><span>${escapeHtml(c.category||"OC")}</span></div>
  </div>
 </article>`;
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}

function renderGrid(id,list){
 const el=$(id); el.innerHTML=list.length?list.map(card).join(""):`<div class="muted">Nothing here yet.</div>`;
 el.querySelectorAll(".card").forEach(x=>x.onclick=()=>openChat(x.dataset.id));
}
function render(){
 const q=($("#searchInput")?.value||"").toLowerCase();
 const filtered=characters.filter(c=>(activeCategory==="All"||c.category===activeCategory)&&(!q||`${c.name} ${c.description} ${c.category}`.toLowerCase().includes(q)));
 renderGrid("#featuredGrid",characters.slice(0,4));
 renderGrid("#discoverGrid",filtered);
 renderGrid("#favoritesGrid",characters.filter(c=>favorites.includes(c.id)));
 renderHistory();
 const cats=["All",...new Set(characters.map(c=>c.category||"OC"))];
 $("#categoryChips").innerHTML=cats.map(c=>`<button class="chip ${c===activeCategory?"active":""}" data-cat="${escapeHtml(c)}">${escapeHtml(c)}</button>`).join("");
 $("#discoverChips").innerHTML=$("#categoryChips").innerHTML;
 $$(".chip").forEach(b=>b.onclick=()=>{activeCategory=b.dataset.cat;render()});
 renderRecent();
}
function renderRecent(){
 const ids=Object.keys(histories).slice(-5).reverse();
 $("#recentChats").innerHTML=ids.map(id=>{const c=characters.find(x=>x.id===id);return c?`<div class="recent" data-id="${id}">${c.emoji} ${escapeHtml(c.name)}</div>`:""}).join("");
 $$(".recent").forEach(x=>x.onclick=()=>openChat(x.dataset.id));
}
function renderHistory(){
 const entries=Object.entries(histories).reverse();
 $("#chatHistory").innerHTML=entries.length?entries.map(([id,msgs])=>{const c=characters.find(x=>x.id===id);const last=msgs.at(-1);return `<div class="history-item" data-id="${id}"><strong>${c?.emoji||"✦"} ${escapeHtml(c?.name||"Character")}</strong><div class="muted">${escapeHtml(last?.content||"No messages yet")}</div></div>`}).join(""):`<div class="muted">Start a conversation and it will appear here.</div>`;
 $$(".history-item").forEach(x=>x.onclick=()=>openChat(x.dataset.id));
}

function openChat(id){
 current=characters.find(c=>c.id===id); if(!current)return;
 $("#chatName").textContent=current.name;
 $("#chatStatus").textContent="Online";
 $("#chatAvatar").textContent=current.emoji||"✦";
 $("#favChatBtn").textContent=favorites.includes(id)?"♥":"♡";
 showView("chat");
 const msgs=histories[id]||[{role:"assistant",content:`Hey! I'm ${current.name}. What do you want to talk about?`}];
 if(!histories[id]) histories[id]=msgs;
 renderMessages();
 save();
}
function renderMessages(){
 const box=$("#messages");
 box.innerHTML=(histories[current.id]||[]).map(m=>`<div class="bubble ${m.role}">${escapeHtml(m.content)}</div>`).join("");
 box.scrollTop=box.scrollHeight;
}
async function send(){
 const input=$("#messageInput"); const text=input.value.trim();
 if(!text||!current)return;
 histories[current.id]=histories[current.id]||[];
 histories[current.id].push({role:"user",content:text});
 input.value=""; renderMessages(); $("#typing").classList.remove("hidden");
 try{
  const r=await fetch("/api/chat",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({character:current,messages:histories[current.id],memory:memory[current.id]||[]})});
  const data=await r.json();
  if(!r.ok) throw new Error(data.error||"AI request failed");
  histories[current.id].push({role:"assistant",content:data.text});
 }catch(e){
  histories[current.id].push({role:"assistant",content:"I can't connect to the AI right now. Check the server setup and try again."});
  console.error(e);
 }finally{
  $("#typing").classList.add("hidden"); renderMessages(); save();
 }
}

$("#sendBtn").onclick=send;
$("#messageInput").addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();send()}});
$("#backBtn").onclick=()=>showView("home");
$("#favChatBtn").onclick=()=>{if(!current)return;favorites=favorites.includes(current.id)?favorites.filter(x=>x!==current.id):[...favorites,current.id];$("#favChatBtn").textContent=favorites.includes(current.id)?"♥":"♡";save();render()};
$("#searchInput").oninput=render;
$("#discoverSearch").oninput=()=>{const q=$("#discoverSearch").value.toLowerCase();renderGrid("#discoverGrid",characters.filter(c=>(activeCategory==="All"||c.category===activeCategory)&&`${c.name} ${c.description}`.toLowerCase().includes(q)))};

$$(".nav").forEach(n=>n.onclick=()=>{showView(n.dataset.view);render()});
$$(".text-btn").forEach(b=>b.onclick=()=>showView(b.dataset.view));
$("#mobileMenu").onclick=()=>$(".sidebar").classList.toggle("open");
$("#themeBtn").onclick=()=>document.body.classList.toggle("glow");

$("#createForm").onsubmit=e=>{
 e.preventDefault();
 const f=new FormData(e.target);
 const c={id:"custom-"+Date.now(),name:f.get("name"),description:f.get("description"),personality:f.get("personality"),style:f.get("style"),category:f.get("category")||"OC",emoji:"✦"};
 characters.push(c);save();e.target.reset();render();openChat(c.id);
};

render();
