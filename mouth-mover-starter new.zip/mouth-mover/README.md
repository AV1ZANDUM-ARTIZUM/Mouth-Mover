# Mouth Mover

A starter AI-character chat website with an original dark neon UI.

## Features
- Character discovery and search
- Character cards with personalities
- Real AI chat through a server-side API
- Character creator
- Local chat history and favorites
- Lightweight memory notes
- Basic safety behavior
- Responsive layout

## Run locally

1. Install Node.js 18+.
2. Open this folder in a terminal.
3. Run `npm install`.
4. Copy `.env.example` to `.env`.
5. Add your API key and choose a model.
6. Run `npm run dev`.
7. Open the local address printed by Node.

## Important
Do not put an AI API key in the browser code or commit `.env` to GitHub.

GitHub Pages can host the frontend, but a real AI API key must stay on a server. For a public deployment, host the `server` API on a backend service and point the frontend API URL at it.
