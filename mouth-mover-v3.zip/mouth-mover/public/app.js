const seedCharacters=[
{id:"zayne",name:"Zayne",description:"A mysterious strategist who always seems one step ahead.",personality:"Calm, clever, observant, dry sense of humor.",style:"Short, confident replies with occasional teasing.",category:"Mystery",emoji:"🖤",tags:["Clever","Mysterious","Calm"]},
{id:"luna",name:"Luna",description:"An energetic dreamer who loves impossible ideas.",personality:"Cheerful, curious, imaginative and supportive.",style:"Expressive and upbeat.",category:"Fantasy",emoji:"🌙",tags:["Dreamy","Friendly","Creative"]},
{id:"kai",name:"Kai",description:"A quiet inventor who would rather build than brag.",personality:"Reserved, thoughtful, loyal and analytical.",style:"Concise and thoughtful.",category:"Sci-Fi",emoji:"⚙️",tags:["Inventor","Smart","Quiet"]},
{id:"elara",name:"Elara",description:"A mysterious traveler with a talent for strange stories.",personality:"Confident, playful, secretive and kind.",style:"Dramatic but friendly.",category:"Adventure",emoji:"✨",tags:["Traveler","Stories","Playful"]},
{id:"calix",name:"Calix",description:"Your competitive classmate who secretly wants to help.",personality:"Competitive, witty, protective and honest.",style:"Casual banter.",category:"School",emoji:"📚",tags:["Funny","Competitive","School"]},
{id:"seraphina",name:"Seraphina",description:"A cosmic storyteller who collects questions about the universe.",personality:"Wise, curious, gentle and enthusiastic.",style:"Poetic but easy to understand.",category:"Fantasy",emoji:"🌌",tags:["Cosmic","Wise","Stories"]}
];

let characters=JSON.parse(localStorage.getItem("mm_characters")||"null")||seedCharacters;
let favorites=JSON.parse(localStorage.getItem("mm_favorites")||"[]");
let histories=JSON.parse(localStorage.getItem("mm_histories")||"{}");
let current=null,activeCategory="All";
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const esc=s=>String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));
function save(){localStorage.setItem("mm_characters",JSON.stringify(characters));localStorage.setItem("mm_favorites",JSON.stringify(favorites));localStorage.setItem("mm_histories",JSON.stringify(histories))}
function toast(t){const x=$("#toast");x.textContent=t;x.classList.add("show");setTimeout(()=>x.classList.remove("show"),1800)}
function showView(name){$$(".view").forEach(v=>v.classList.remove("active-view"));$(`#${name}View`).classList.add("active-view");$$(".nav").forEach(n=>n.classList.toggle("active",n.dataset.view===name));$$(".bottom").forEach(n=>n.classList.toggle("active",n.dataset.view===name));$(".sidebar")?.classList.remove("open");window.scrollTo(0,0)}
function card(c){return `<article class="character-card" data-id="${esc(c.id)}"><div class="card-art">${c.emoji||"✦"}</div><div class="card-body"><h3>${esc(c.name)}</h3><p>${esc(c.description)}</p><div class="card-meta"><span>${favorites.includes(c.id)?"♥":"♡"} ${esc(c.category||"OC")}</span><span>Talk →</span></div></div></article>`}
function renderHome(){renderRow("#popularRow",characters.slice(0,5));const ids=Object.keys(histories).slice(-5).reverse();const list=ids.map(id=>characters.find(c=>c.id===id)).filter(Boolean);renderRow("#continueRow",list.length?list:characters.slice(2,5));$("#moodRow").innerHTML=["All",...new Set(characters.map(c=>c.category||"OC"))].map(x=>`<button class="mood" data-mood="${esc(x)}">${x==="All"?"✦":x==="Fantasy"?"☾":x==="Mystery"?"◈":x==="Sci-Fi"?"⚙":"✦"} ${esc(x)}</button>`).join("");$$(".mood").forEach(x=>x.onclick=()=>{activeCategory=x.dataset.mood;showView("discover");renderDiscover()})}
function renderRow(sel,list){const el=$(sel);el.innerHTML=list.length?list.map(card).join(""):`<div class="empty">No conversations yet.</div>`;el.querySelectorAll("[data-id]").forEach(x=>x.onclick=()=>openCharacter(x.dataset.id))}
function renderDiscover(){const q=($("#discoverSearch")?.value||"").toLowerCase();const list=characters.filter(c=>(activeCategory==="All"||c.category===activeCategory)&&(!q||`${c.name} ${c.description} ${c.personality} ${c.category} ${c.tags?.join(" ")}`.toLowerCase().includes(q)));renderGrid("#discoverGrid",list);const cats=["All",...new Set(characters.map(c=>c.category||"OC"))];$("#discoverChips").innerHTML=cats.map(c=>`<button class="chip ${c===activeCategory?"active":""}" data-cat="${esc(c)}">${esc(c)}</button>`).join("");$$(".chip").forEach(x=>x.onclick=()=>{activeCategory=x.dataset.cat;renderDiscover()})}
function renderGrid(sel,list){const el=$(sel);el.innerHTML=list.length?list.map(card).join(""):`<div class="empty">Nothing here yet.</div>`;el.querySelectorAll("[data-id]").forEach(x=>x.onclick=()=>openCharacter(x.dataset.id))}
function renderFavorites(){renderGrid("#favoritesGrid",characters.filter(c=>favorites.includes(c.id)))}
function renderHistory(){const entries=Object.entries(histories).reverse();$("#chatHistory").innerHTML=entries.length?entries.map(([id,msgs])=>{const c=characters.find(x=>x.id===id),last=msgs.at(-1);return `<div class="history-item" data-id="${id}"><div class="history-art">${c?.emoji||"✦"}</div><div class="history-text"><b>${esc(c?.name||"Character")}</b><p>${esc(last?.content||"")}</p></div><span class="history-time">›</span></div>`}).join(""):`<div class="empty">Your conversations will appear here.</div>`;$$(".history-item").forEach(x=>x.onclick=()=>openChat(x.dataset.id))}
function renderRecent(){$("#recentChats").innerHTML=Object.keys(histories).slice(-4).reverse().map(id=>{const c=characters.find(x=>x.id===id);return c?`<div class="recent">${c.emoji} ${esc(c.name)}</div>`:""}).join("")}
function renderProfile(){$("#statFav").textContent=favorites.length;$("#statChats").textContent=Object.keys(histories).length;$("#statCreated").textContent=characters.filter(c=>c.id.startsWith("custom-")).length}
function renderAll(){renderHome();renderDiscover();renderFavorites();renderHistory();renderRecent();renderProfile()}
function openCharacter(id){current=characters.find(c=>c.id===id);if(!current)return;$("#profileArt").textContent=current.emoji||"✦";$("#profileName").textContent=current.name;$("#profileDescription").textContent=current.description;$("#profileCategory").textContent=current.category||"CHARACTER";$("#profilePersonality").textContent=current.personality;$("#profileTags").innerHTML=(current.tags||[current.category]).map(t=>`<span>${esc(t)}</span>`).join("");showView("character")}
function openChat(id){current=characters.find(c=>c.id===id);if(!current)return;$("#chatName").textContent=current.name;$("#chatAvatar").textContent=current.emoji||"✦";$("#favChatBtn").textContent=favorites.includes(id)?"♥":"♡";histories[id]=histories[id]||[{role:"assistant",content:`Hey! I'm ${current.name}. What should we talk about?`}];showView("chat");renderMessages();save();renderRecent()}
function renderMessages(){const box=$("#messages");box.innerHTML=(histories[current.id]||[]).map(m=>`<div class="bubble ${m.role}">${esc(m.content)}</div>`).join("");box.scrollTop=box.scrollHeight}
async function send(){const input=$("#messageInput"),text=input.value.trim();if(!text||!current)return;histories[current.id].push({role:"user",content:text});input.value="";renderMessages();$("#typing").classList.remove("hidden");try{const r=await fetch("/api/chat",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({character:current,messages:histories[current.id]})});const data=await r.json();if(!r.ok)throw Error(data.error||"AI unavailable");histories[current.id].push({role:"assistant",content:data.text})}catch(e){histories[current.id].push({role:"assistant",content:"I can't reach the AI server yet. Make sure the Mouth Mover backend is running and its AI key is configured."})}finally{$("#typing").classList.add("hidden");renderMessages();save();renderAll()}}
$("#startBtn").onclick=()=>{localStorage.setItem("mm_onboarded","1");$("#onboarding").classList.add("hidden");$("#shell").classList.remove("hidden")};
if(localStorage.getItem("mm_onboarded")){$("#onboarding").classList.add("hidden");$("#shell").classList.remove("hidden")}
$$(".nav,.bottom").forEach(n=>n.onclick=()=>showView(n.dataset.view));
$$("[data-view]").forEach(n=>{if(!n.classList.contains("nav")&&!n.classList.contains("bottom"))n.onclick=()=>showView(n.dataset.view)});
$("#heroBtn").onclick=()=>showView("discover");
$("#profileBtn").onclick=()=>{renderProfile();showView("profile")};
$("#mobileMenu").onclick=()=>$(".sidebar").classList.toggle("open");
$("#discoverSearch").oninput=renderDiscover;
$("#globalSearch").onkeydown=e=>{if(e.key==="Enter"){showView("discover");$("#discoverSearch").value=e.target.value;renderDiscover()}};
$("#characterBack").onclick=()=>showView("home");
$("#profileChat").onclick=()=>openChat(current.id);
$("#chatProfileBtn").onclick=()=>openCharacter(current.id);
$("#backBtn").onclick=()=>showView("home");
$("#favChatBtn").onclick=()=>{favorites=favorites.includes(current.id)?favorites.filter(x=>x!==current.id):[...favorites,current.id];$("#favChatBtn").textContent=favorites.includes(current.id)?"♥":"♡";save();renderAll();toast(favorites.includes(current.id)?"Saved to favorites":"Removed from favorites")};
$("#sendBtn").onclick=send;
$("#messageInput").addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();send()}});
$("#createForm").onsubmit=e=>{e.preventDefault();const f=new FormData(e.target);const c={id:"custom-"+Date.now(),name:f.get("name"),description:f.get("description"),personality:f.get("personality"),style:f.get("style"),category:f.get("category")||"Original",emoji:"✦",tags:[f.get("category")||"Original"]};characters.push(c);save();e.target.reset();renderAll();toast("Character created!");openChat(c.id)};
renderAll();
